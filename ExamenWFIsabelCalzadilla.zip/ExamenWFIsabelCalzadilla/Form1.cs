﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenWFIsabelCalzadilla
{
    public partial class Form1 : Form
    {

        ClsViatges viaje; 

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSolicitar_Click(object sender, EventArgs e)
        {
            string pais = cmbPais.SelectedItem.ToString();
            string estancia = cmbEstancia.SelectedItem.ToString();

            viaje = new ClsViatges(txtDni.Text, Convert.ToInt32(nudNumPersonas.Value), pais, estancia );

            FormReserva reserve = new FormReserva(viaje);

            reserve.ShowDialog();


        }

        private void btnCancalar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
