﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenWFIsabelCalzadilla
{
    public class ClsViatges  // DECLARACION DE CLASE PUBLICA PARA HACERLA ACCESIBLE
    {
        private string _Dni;
        private int _NumPersonas;
        private string _Pais;
        private string _Estancia;

        public ClsViatges(string dni, int persons, string pais, string estancia)
        {
            Dni = dni;
            NumPersonas = persons;
            Pais = pais;
            Estancia = estancia;
        }

        public string Dni { get => _Dni; set => _Dni = value; }
        public int NumPersonas { get => _NumPersonas; set => _NumPersonas = value; }
        public string Pais { get => _Pais; set => _Pais = value; }
        public string Estancia { get => _Estancia; set => _Estancia = value; }

        public string Info()
        {
            return $"Los datos del viaje demandado: \n \n  {Pais}, {Estancia} y {NumPersonas} personas";
        }
    }
}
